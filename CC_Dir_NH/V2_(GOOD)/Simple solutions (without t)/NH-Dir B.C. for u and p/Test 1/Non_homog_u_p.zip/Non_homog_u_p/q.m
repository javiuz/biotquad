function qq=q(xx,~,~)

global c0 

%       qq(xx,yy,tt) = q
    
qq=0;
       
return
end