function sol=sol_exacta_p(i,j,tt)

global x  y

xx=(x(i,j)+x(i+1,j)+x(i+1,j+1)+x(i,j+1))/4;
yy=(y(i,j)+y(i+1,j)+y(i+1,j+1)+y(i,j+1))/4;

% p(xx,yy,tt)

sol=xx*yy*(1 - xx*yy);

return
end