function qq=q(xx,yy,tt)

global c0 perm

%       qq(xx,yy,tt) = q
    
%qq=0;
 qq=-2*perm*((-1 + xx)*xx + (-1 + yy)*yy);     
return
end