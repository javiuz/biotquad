function qq=q(xx,yy,tt)

global c0 perm

%       qq(xx,yy,tt) = q
    
qq=0; 
return
end