function qq=q(xx,yy,tt)

global c0 

%       qq(xx,yy,tt) = q
    
%qq=0;
 qq=-2*(-1 + xx)*xx - 2*(-1 + yy)*yy;     
return
end