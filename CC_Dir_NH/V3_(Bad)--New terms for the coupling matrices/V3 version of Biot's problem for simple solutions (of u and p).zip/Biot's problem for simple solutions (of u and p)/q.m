function qq=q(xx,~,~)

global c0 

%       qq(xx,yy,tt) = q
    
qq=c0*xx;
       
return
end