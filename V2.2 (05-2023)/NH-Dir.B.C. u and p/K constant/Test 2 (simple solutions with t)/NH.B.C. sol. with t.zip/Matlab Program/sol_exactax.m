function sol=sol_exactax(xx,yy,tt,comp)

global perm

%       u(xx,yy,tt) = {u1(xx,yy,tt),u2(xx,yy,tt)}

%         p(xx,yy,tt)

%         z(xx,yy,tt)= {z1(xx,yy,tt),z2xx,yy,tt)}

%         gamma = [0 r;-r 0]
%               = r

 if comp==1         % Soluci�n anal�tica de u1(xx,yy,tt)
     sol=exp(tt)*(xx^2 + xx^3*yy^4 + cos(1 - yy)*sin((1 - xx)*(1 - yy)));
 elseif comp==2     % Soluci�n anal�tica de u2(xx,yy,tt)
     sol=exp(tt)*((1 - yy)^2 + (1 - xx)^4*(1 - yy)^3 + cos(xx*yy)*sin(xx));
 elseif comp==3     % Soluci�n anal�tica de p(xx,yy,tt)
     sol=exp(tt)*(10 + cos(pi*yy)*sin(pi*xx));
 elseif comp==4     % Soluci�n anal�tica de z1(xx,yy,tt)
     sol=-(exp(tt)*perm*pi*cos(pi*xx)*cos(pi*yy));
 elseif comp==5     % Soluci�n anal�tica de z2(xx,yy,tt)
     sol=exp(tt)*perm*pi*sin(pi*xx)*sin(pi*yy);
 else               % Soluci�n anal�tica de gamma (1st row & 2nd column)
     sol=(exp(tt)*(4*(-1 + xx)^3*(-1 + yy)^3 + 4*xx^3*yy^3 + (-1 + xx)*cos(1 - yy)*cos((-1 + xx)*(-1 + yy)) -...
          cos(xx)*cos(xx*yy) + sin(1 - yy)*sin((-1 + xx)*(-1 + yy)) + yy*sin(xx)*sin(xx*yy)))/2.;
 end

return
end